#include <stdio.h>		/* Basic I/O routines          */
#include <sys/types.h>		/* standard system types       */
#include <netinet/in.h>		/* Internet address structures */
#include <sys/socket.h>		/* socket interface functions  */
#include <netdb.h>		/* host to IP resolution       */
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include "readline.h"
#include "rmnewline.h"
#include "rmhead.h"
#include "dump_line.h"

#define SA struct sockaddr
#define MAXLINE     4096
#define	HOSTNAMELEN	40	  /* maximal host name length */
#define	BUFLEN	  	1024	/* maximum response size    */


char ip[100];
int port=0;


// after connect success, do this func
void doit(int sockfd){
  char	sendline[MAXLINE] , recvline[MAXLINE] ;
  int i,n,maxfd,len,sel,init=0;
  static char name[100],send[MAXLINE+100];
  fd_set rset, allset;


  FD_ZERO(&rset);
  if(sockfd>fileno(stdin))maxfd=sockfd;
  else maxfd=fileno(stdin);
  // add stdin & sockfd in set
  FD_SET(sockfd,&allset);
  FD_SET(fileno(stdin),&allset);


  printf("[Server] What's your name?\n");
  // set name
  while(1){
    rset=allset;
    sel=select(maxfd+1,&rset,NULL,NULL,NULL);
    if(sel<0)printf("select error!\n");
    
    if(FD_ISSET(fileno(stdin),&rset)){
      while(1){
        fgets(name,100,stdin);
        len=strlen(name);
        if( len<3 || len>13 ){
          printf("[Server] Username can only consists of 2~12 digits or English letters.\n");
        }else break;
      }
      memset(send,'\0',MAXLINE+100);
      strcat(send,"/initName:");
      strcat(send,name);
      len=strlen(send);
      if((write(sockfd, send , len))!=len)exit(0);
      rmnewline(name);
      printf("[Server] Hello %s, welcome! ServerIP: %s %d\n",name,ip,port);
      break;
    }
  }
  
  while(1){
    rset=allset;
    sel=select(maxfd+1,&rset,NULL,NULL,NULL);
    if(sel<0)continue;
   
    // get message from server
    if(FD_ISSET(sockfd,&rset)){
      if((n=readline(sockfd,recvline,MAXLINE))>0)printf("%s",recvline);
      else if(n==0)printf("close connection\n"),exit(0);
      else if(n<0)printf("error!\n");
    }
    
    // get message from stdin
    if(FD_ISSET(fileno(stdin),&rset)){
      // chat
      memset(send,'\0',MAXLINE+100);
      fgets(sendline ,MAXLINE ,stdin);
      strcat(send,sendline);
      len=strlen(send);
      if((write(sockfd, send , len))!=len)exit(0);
    }
  }
}


int main(int argc,char* argv[]){

  int sockfd;
  struct sockaddr_in servaddr;
  struct hostent*     hen; 
  char buf[100];

   if(argc < 3 ){
     while(1){
       printf("It is not connected to any server\n");
       printf("Please use /connect <IP address> <Portnumber>\n");
       scanf("%s %s %d",&buf,&ip,&port);
       dump_line(stdin);
       if( !strcmp(buf,"/connect") ){
         if( hen=gethostbyname(ip) ){
           if(port>0){
             break;
           }
         }
       }
     }
   }else{
     /* Address resolution stage */
     hen = gethostbyname(argv[1]);
     strcpy(ip,argv[1]);
     if (!hen) {
       perror("couldn't resolve host name");
     }
  }

  sockfd = socket(AF_INET , SOCK_STREAM , 0);

  /* first clear out the struct, to avoid garbage  */
  memset(&servaddr, 0, sizeof(servaddr));			 

  /* Using Internet address family */
  servaddr.sin_family = AF_INET;		        	  

  /* copy port number in network byte order */
  if(argc>=3){
    servaddr.sin_port = htons(port=atoi(argv[2]));		      	  
  }else{
    servaddr.sin_port = htons(port);
  }
  /* copy IP address into address struct */
  memcpy(&servaddr.sin_addr.s_addr, hen->h_addr_list[0], hen->h_length); 	

  connect( sockfd , (SA * ) &servaddr , sizeof(servaddr) );

  doit(sockfd);

  exit(0);
}

